﻿using System;

namespace CreditCardInterest
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hello World!");
        }       
    }
}
